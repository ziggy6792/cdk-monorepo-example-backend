import 'source-map-support/register';
export declare const handler: (event: any) => Promise<any>;
